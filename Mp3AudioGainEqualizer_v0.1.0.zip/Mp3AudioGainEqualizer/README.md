# MP3 Audio Gain and Equalizer (prototype 0.1)

Independent Android Kotlin/Jetpack Compose app project. It includes a full-track preview player, +/- gain controls, preset buttons, a first-pass Android Equalizer integration, and the planned dark/orange UI.

## Build with GitHub Actions
1. Create a new GitHub repository named `Mp3AudioGainEqualizer`.
2. Upload the contents of this project ZIP to the repository root (not the containing folder).
3. Open **Actions** and run **Build MP3 Audio Gain and Equalizer APK**. It also runs on pushes.
4. Download the `Mp3AudioGainEqualizer-debug-apk` artifact; it contains `app-debug.apk`.

## Important prototype limitations
- MP3 export/re-encoding is not implemented yet. The Apply & Save button explicitly reports this.
- L/R meters are currently design placeholders, not measured PCM peak levels. Real per-channel 0 dBFS over detection requires PCM decode/processing integration.
- Gain control affects preview playback only and is capped by Android's normal MediaPlayer volume path, so positive dB values are not true >100% amplification.
- Equalizer effect support and band layout depend on device/vendor; verify on target devices.
- No APK has been built or tested in this environment. Use GitHub Actions to compile and inspect the build log before installing.
