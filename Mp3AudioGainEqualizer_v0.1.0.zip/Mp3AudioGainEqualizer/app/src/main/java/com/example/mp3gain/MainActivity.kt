package com.example.mp3gain

import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Bg = Color(0xFF101112)
private val Panel = Color(0xFF1D1F21)
private val Orange = Color(0xFFFF642D)
private val Green = Color(0xFF4BC66A)
private val Yellow = Color(0xFFFFC247)
private val Red = Color(0xFFFF3B42)

class MainActivity : ComponentActivity() {
    private var player: MediaPlayer? = null
    private var equalizer: Equalizer? = null
    private var sessionId: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var uri by remember { mutableStateOf<Uri?>(null) }
            var fileName by remember { mutableStateOf("MP3ファイルを選択してください") }
            var playing by remember { mutableStateOf(false) }
            var gain by remember { mutableFloatStateOf(0f) }
            var progress by remember { mutableFloatStateOf(0f) }
            var durationMs by remember { mutableIntStateOf(0) }
            var positionMs by remember { mutableIntStateOf(0) }
            var status by remember { mutableStateOf("ファイル未選択") }
            var eqEnabled by remember { mutableStateOf(false) }
            var eqBands by remember { mutableStateOf(listOf(0f, 0f, 0f, 0f, 0f)) }
            val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { picked ->
                if (picked != null) {
                    uri = picked
                    contentResolver.takePersistableUriPermission(picked, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    fileName = picked.lastPathSegment?.substringAfterLast('/') ?: "選択したMP3"
                    player?.release(); player = null; equalizer?.release(); equalizer = null
                    try {
                        player = MediaPlayer().apply {
                            setDataSource(this@MainActivity, picked)
                            setOnPreparedListener { mp ->
                                durationMs = mp.duration
                                sessionId = mp.audioSessionId
                                try { equalizer = Equalizer(0, sessionId).apply { enabled = eqEnabled } } catch (_: Exception) {}
                                status = "再生準備完了"
                                mp.setVolume(gainVolume(gain), gainVolume(gain))
                            }
                            setOnCompletionListener { playing = false; status = "再生完了" }
                            prepareAsync()
                        }
                        status = "読み込み中…"
                    } catch (e: Exception) { status = "読み込み失敗: ${e.message}" }
                }
            }
            MaterialTheme(colorScheme = darkColorScheme(primary = Orange, background = Bg, surface = Panel)) {
                Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("MP3 AUDIO GAIN", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text("AND EQUALIZER", color = Orange, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("FULL TRACK PREVIEW", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(fileName, color = Color.White, fontWeight = FontWeight.Medium)
                            Text(status, color = Color.LightGray, fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                FilledTonalButton(onClick = { picker.launch(arrayOf("audio/mpeg", "audio/*")) }) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("MP3を選択") }
                                IconButton(onClick = {
                                    val p = player
                                    if (p != null && p.isPlaying) { p.pause(); playing = false; status = "一時停止" }
                                    else if (p != null) { try { p.start(); playing = true; status = "再生中" } catch (_: Exception) { status = "再生準備中です" } }
                                }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Orange) }
                                IconButton(onClick = { player?.pause(); player?.seekTo(0); playing = false; positionMs = 0; status = "停止" }) { Icon(Icons.Default.Stop, null, tint = Color.White) }
                            }
                            Slider(value = progress, onValueChange = { progress = it }, onValueChangeFinished = { player?.seekTo((durationMs * progress).toInt()) }, colors = SliderDefaults.colors(thumbColor = Orange, activeTrackColor = Orange))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(timeText(positionMs), color = Color.LightGray, fontSize = 11.sp)
                                Text(timeText(durationMs), color = Color.LightGray, fontSize = 11.sp)
                            }
                            LaunchedEffect(playing, uri) {
                                while (playing) {
                                    val p = player
                                    if (p != null && p.isPlaying) {
                                        positionMs = p.currentPosition
                                        if (durationMs > 0) progress = positionMs.toFloat() / durationMs
                                    }
                                    kotlinx.coroutines.delay(100)
                                }
                            }
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("GAIN CONTROL", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(onClick = { gain = (gain - 0.5f).coerceAtLeast(-24f); player?.setVolume(gainVolume(gain), gainVolume(gain)) }) { Text("−", fontSize = 24.sp) }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(String.format(Locale.US, "%+.1f dB", gain), color = Orange, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                                    Text("0 dB = original level", color = Color.LightGray, fontSize = 11.sp)
                                }
                                OutlinedButton(onClick = { gain = (gain + 0.5f).coerceAtMost(12f); player?.setVolume(gainVolume(gain), gainVolume(gain)) }) { Text("+", fontSize = 24.sp) }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("SILENT", "NORMAL", "MAX").forEach { preset ->
                                    val selected = when (preset) { "SILENT" -> gain <= -23.5f; "NORMAL" -> gain == 0f; else -> gain >= 5.5f }
                                    Button(onClick = { gain = when (preset) { "SILENT" -> -24f; "NORMAL" -> 0f; else -> 6f }; player?.setVolume(gainVolume(gain), gainVolume(gain)) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (selected) Orange else Color(0xFF343638))) { Text(preset, fontSize = 10.sp) }
                                }
                            }
                            Text("※ プレビュー音量に反映します。ファイルへの書き出しは次の実装段階です。", color = Yellow, fontSize = 11.sp)
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("STEREO PEAK METER", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("L / Rの実測メーターはPCM音声処理段階で接続します", color = Color.LightGray, fontSize = 11.sp)
                            listOf("L", "R").forEach { channel ->
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text(channel, color = Color.White, fontWeight = FontWeight.Bold)
                                    Row(Modifier.weight(1f).height(18.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                        repeat(20) { i -> Box(Modifier.weight(1f).fillMaxHeight().background(when { i < 12 -> Green.copy(alpha = .65f); i < 17 -> Yellow.copy(alpha = .65f); else -> Red.copy(alpha = .65f) }, RoundedCornerShape(2.dp))) }
                                    }
                                    Text("— dBFS", color = Color.LightGray, fontSize = 10.sp)
                                }
                            }
                            Text("赤色はオーバー検出時の表示予定。現在はデザイン確認用です。", color = Yellow, fontSize = 11.sp)
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("AUDIO EQUALIZER", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Switch(checked = eqEnabled, onCheckedChange = { enabled -> eqEnabled = enabled; equalizer?.enabled = enabled })
                            }
                            val names = listOf("60 Hz", "230 Hz", "910 Hz", "3.6 kHz", "14 kHz")
                            names.forEachIndexed { index, name ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(name, color = Color.LightGray, modifier = Modifier.width(58.dp), fontSize = 11.sp)
                                    IconButton(onClick = { val n = eqBands.toMutableList(); n[index] = (n[index] - 1f).coerceAtLeast(-6f); eqBands = n; applyEq(index, n[index]) }) { Text("−", color = Color.White) }
                                    Text(String.format(Locale.US, "%+.0f dB", eqBands[index]), color = Color.White, modifier = Modifier.width(55.dp))
                                    IconButton(onClick = { val n = eqBands.toMutableList(); n[index] = (n[index] + 1f).coerceAtMost(6f); eqBands = n; applyEq(index, n[index]) }) { Text("+", color = Color.White) }
                                }
                            }
                            Text("EQは端末のAudioEffect対応状況に依存します。", color = Color.LightGray, fontSize = 11.sp)
                        }
                    }
                    Button(onClick = { status = "保存機能は次段階で実装します。元ファイルは変更していません。" }, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange), shape = RoundedCornerShape(10.dp)) {
                        Text("APPLY & SAVE MP3", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Text("Prototype 0.1 · Audio export and true L/R peak detection are not implemented yet.", color = Color.Gray, fontSize = 10.sp)
                }
            }
        }
    }
    private fun gainVolume(db: Float): Float = Math.pow(10.0, db.toDouble() / 20.0).toFloat().coerceIn(0f, 1f)
    private fun applyEq(index: Int, db: Float) {
        try {
            val eq = equalizer ?: return
            if (index >= eq.numberOfBands) return
            val range = eq.bandLevelRange
            val millibels = (db * 100).toInt().coerceIn(range[0].toInt(), range[1].toInt()).toShort()
            eq.setBandLevel(index.toShort(), millibels)
        } catch (_: Exception) { }
    }
    override fun onDestroy() { equalizer?.release(); player?.release(); equalizer = null; player = null; super.onDestroy() }
}

private fun timeText(ms: Int): String {
    val total = (ms.coerceAtLeast(0) / 1000)
    return String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
}
